# bot.py
# Deploy-ready Telegram bot (Polling) with referral -> VIP, mandatory channel check.
# LANGUAGE: Uzbek
# Do NOT put your token here. Use env var TG_BOT_TOKEN on the hosting platform (Railway/Heroku).

import os
import sqlite3
import time
import logging
from typing import Optional
from telebot import TeleBot, types
from telebot.apihelper import ApiTelegramException

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# === Config from environment ===
TG_BOT_TOKEN = os.getenv("TG_BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
MANDATORY_CHANNELS = os.getenv("MANDATORY_CHANNELS", "@TopSxemaKana1,@instaheshteg2").split(",")
VIP_CHANNEL = os.getenv("VIP_CHANNEL", "")  # e.g. @vip_channel or invite link

if not TG_BOT_TOKEN:
    logger.error("TG_BOT_TOKEN muhit o'zgaruvchisi topilmadi. Bot to'xtadi.")
    raise SystemExit("Provide TG_BOT_TOKEN env var")

bot = TeleBot(TG_BOT_TOKEN, threaded=True)

# Database (sqlite) setup
DB_PATH = os.getenv("DB_PATH", "botdata.sqlite3")
conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cur = conn.cursor()

def init_db():
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        referrer INTEGER,
        referrals INTEGER DEFAULT 0,
        is_vip INTEGER DEFAULT 0,
        promoted_at TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS referrals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        referrer INTEGER,
        referred INTEGER,
        created_at INTEGER
    )
    """)
    conn.commit()

init_db()

# Utility DB functions
def get_user(uid: int) -> Optional[tuple]:
    cur.execute("SELECT * FROM users WHERE id=?", (uid,))
    return cur.fetchone()

def add_or_update_user(uid: int, username: str=None, first_name: str=None, referrer: int=None):
    u = get_user(uid)
    if u is None:
        cur.execute("INSERT INTO users (id, username, first_name, referrer) VALUES (?, ?, ?, ?)",
                    (uid, username, first_name, referrer))
    else:
        cur.execute("UPDATE users SET username=?, first_name=? WHERE id=?", (username, first_name, uid))
    conn.commit()

def increment_referrals(referrer_id: int, new_referred: int):
    cur.execute("UPDATE users SET referrals = referrals + 1 WHERE id=?", (referrer_id,))
    cur.execute("INSERT INTO referrals (referrer, referred, created_at) VALUES (?, ?, ?)",
                (referrer_id, new_referred, int(time.time())))
    conn.commit()
    cur.execute("SELECT referrals FROM users WHERE id=?", (referrer_id,))
    r = cur.fetchone()
    return r[0] if r else 0

def set_vip(uid: int):
    cur.execute("UPDATE users SET is_vip=1, promoted_at=datetime('now') WHERE id=?", (uid,))
    conn.commit()

def list_users():
    cur.execute("SELECT id FROM users")
    return [r[0] for r in cur.fetchall()]

# Mandatory subscription check
def check_subscriptions(user_id: int):
    for ch in MANDATORY_CHANNELS:
        ch = ch.strip()
        if not ch:
            continue
        try:
            member = bot.get_chat_member(ch, user_id)
            status = getattr(member, 'status', None)
            if status in ("creator", "administrator", "member", "restricted"):
                continue
            else:
                return False, f"Siz {ch} kanaliga a'zo emassiz (status={status})"
        except ApiTelegramException as e:
            text = str(e).lower()
            logger.warning("check_subscriptions error for %s -> %s", ch, e)
            if "chat not found" in text or "bad request" in text or "chat_id_invalid" in text:
                return False, f"Bot {ch} kanalini tekshira olmadi. Kanalni tekshiring yoki botni kanal admin qiling."
            if "forbidden" in text or "bot is not a member" in text:
                return False, f"Bot {ch} kanalga qo'shilmagan yoki ruxsat yo'q. Kanalga botni qo'shing."
            return False, f"Kanalni tekshirishda xatolik: {e}"
    return True, ""

# Helper to build referral link for a user
def referral_link_for(uid: int):
    bot_username = bot.get_me().username
    return f"https://t.me/{bot_username}?start=ref{uid}"

# Start handler: support referral param
@bot.message_handler(commands=['start'])
def handle_start(msg: types.Message):
    arg = None
    try:
        parts = msg.text.split()
        if len(parts) > 1:
            arg = parts[1]
    except Exception:
        arg = None

    ref_id = None
    if arg and arg.startswith("ref"):
        try:
            ref_id = int(arg[3:])
        except:
            ref_id = None

    user = get_user(msg.from_user.id)
    username = msg.from_user.username
    fname = msg.from_user.first_name
    # if new user and has referrer, set and increment
    if user is None:
        add_or_update_user(msg.from_user.id, username, fname, referrer=ref_id)
        if ref_id and ref_id != msg.from_user.id:
            if get_user(ref_id):
                newcount = increment_referrals(ref_id, msg.from_user.id)
                logger.info("Referrer %s got a new referral: %s (total %s)", ref_id, msg.from_user.id, newcount)
                try_promotion(ref_id, newcount)
            else:
                add_or_update_user(ref_id, None, None, None)
                newcount = increment_referrals(ref_id, msg.from_user.id)
                try_promotion(ref_id, newcount)
    else:
        add_or_update_user(msg.from_user.id, username, fname, referrer=user[3] if user else None)

    ok, err = check_subscriptions(msg.from_user.id)
    if not ok:
        kb = types.InlineKeyboardMarkup()
        for ch in MANDATORY_CHANNELS:
            if not ch: continue
            kb.add(types.InlineKeyboardButton(text=f"Obuna: {ch}", url=f"https://t.me/{ch.strip().lstrip('@')}"))
        kb.add(types.InlineKeyboardButton(text="✅ Men obuna bo'ldim", callback_data="check_join"))
        bot.send_message(msg.chat.id, "Botni ishlatish uchun quyidagi kanallarga obuna bo'ling:", reply_markup=kb)
        return

    link = referral_link_for(msg.from_user.id)
    bot.send_message(msg.chat.id,
                     "Xush kelibsiz! Botdan foydalanish uchun menyudan foydalaning.\n\n"
                     f"Sizning referal linkingiz:\n{link}\n\n"
                     "50 ta referal -> VIP. 80+ -> Rekka tahlil (admin bilan).")

    add_or_update_user(msg.from_user.id, username, fname, referrer=ref_id)

    send_main_menu(msg.chat.id)

def send_main_menu(chat_id: int):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row("📈 Rekka chiqish sirlari", "🏆 Top sxemalar")
    markup.row("#️⃣ Hashtag generator", "🔗 Mening ref")
    bot.send_message(chat_id, "Asosiy menyu:", reply_markup=markup)

# Content library
def rekkas_text():
    return (
        "📈 Rekka chiqish sirlari (qisqacha):\n\n"
        "- Hook: birinchi 1-3 soniya juda muhim.\n"
        "- Thumbnail: oddiy fon + katta kontrast shrift.\n"
        "- Hashtag: 3 ta trend + 7-12 niche.\n"
        "- 10-15 daqiqa ichida 10-30 organik interaksiya (comments/likes) qilsa reach oshadi.\n"
        "- A/B test: 5 ta sarlavhada test qiling.\n"
        "...\n(To'liq ensiklopediya admin panelda boshqariladi)"
    )

def sxemalar_text():
    return (
        "🏆 Top sxemalar:\n"
        "1) 1/3 qoidasi: 1 viral, 1 shaxsiy, 1 ta foydali kontent.\n"
        "2) Trend combo: trend audio + hook + 3 trend hashtag.\n"
        "3) 1-soat engagement boost: chiqgach 1 soat ichida 10-20 organik komment qiling.\n"
        "4) Kollab: 2-3 account bilan cross-promote.\n"
    )

# Hashtag categories
HASHTAG_CATEGORIES = {
    '⚽ Futbol': ["#football","#soccer","#futbol","#goals","#matchday","#footballlife"],
    '🚗 Mashina': ["#car","#supercar","#carsofinstagram","#autos","#drift","#carporn"],
    '🎮 O‘yin': ["#gaming","#gamer","#gameplay","#letsplay","#pcgaming","#fortnite"],
    '💡 Faktlar': ["#facts","#didyouknow","#interestingfacts","#learn","#knowledge","#factsoftheday"]
}

@bot.message_handler(func=lambda m: m.text == "📈 Rekka chiqish sirlari")
def m_rekka(m: types.Message):
    bot.send_message(m.chat.id, rekkas_text())

@bot.message_handler(func=lambda m: m.text == "🏆 Top sxemalar")
def m_sxema(m: types.Message):
    bot.send_message(m.chat.id, sxemalar_text())

@bot.message_handler(func=lambda m: m.text == "#️⃣ Hashtag generator")
def m_hashtag(m: types.Message):
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row("⚽ Futbol", "🚗 Mashina")
    kb.row("🎮 O‘yin", "💡 Faktlar")
    kb.row("🔙 Orqaga")
    bot.send_message(m.chat.id, "Kategoriyani tanlang:", reply_markup=kb)

@bot.message_handler(func=lambda m: m.text in HASHTAG_CATEGORIES.keys())
def m_send_hashtags(m: types.Message):
    tags = " ".join(HASHTAG_CATEGORIES.get(m.text, []))
    bot.send_message(m.chat.id, f"🧠 {m.text} uchun heshteglar:\n\n{tags}\n\nMaslahat: 10-25 tag oralig'ida foydalaning.")

@bot.message_handler(func=lambda m: m.text == "🔗 Mening ref")
def m_refinfo(m: types.Message):
    link = referral_link_for(m.from_user.id)
    u = get_user(m.from_user.id)
    referrals = u[4] if u else 0
    bot.send_message(m.chat.id, f"Sizning referal linkingiz:\n{link}\n\nSiz hozir {referrals} ta referalga egasiz.\n50 -> VIP, 80 -> Rekka tahlil (admin bilan).")

@bot.message_handler(func=lambda m: m.text == "🔙 Orqaga")
def m_back(m: types.Message):
    send_main_menu(m.chat.id)

# Referral promotion logic
def try_promotion(referrer_id: int, newcount: int):
    try:
        if newcount >= 80:
            set_vip(referrer_id)
            bot.send_message(referrer_id, "🎉 Tabrik! Siz 80+ referal to'pladingiz — Rekka tahlil (admin bilan) imkoniyati ochildi. Admin bilan bog'laning.")
            if ADMIN_ID:
                bot.send_message(ADMIN_ID, f"USER {referrer_id} has >=80 referrals — please provide Rekka analysis.")
        elif newcount >= 50:
            set_vip(referrer_id)
            vip_channel = VIP_CHANNEL
            if vip_channel:
                try:
                    # Try to create invite link if bot is admin
                    inv = bot.create_chat_invite_link(vip_channel)
                    bot.send_message(referrer_id, f"✅ Siz VIP bo'ldingiz! VIP kanalga kirish: {inv.invite_link}")
                except Exception as e:
                    logger.warning("invite create failed: %s", e)
                    bot.send_message(referrer_id, f"✅ Siz VIP bo'ldingiz! Iltimos admin sizni VIP kanalga qo'shadi. Kanal: {vip_channel}")
            else:
                bot.send_message(referrer_id, "✅ Siz VIP bo'ldingiz! Iltimos admin sizni VIP kanalga qo'shadi.")
            if ADMIN_ID:
                bot.send_message(ADMIN_ID, f"USER {referrer_id} promoted to VIP (>=50 referrals).")
    except Exception as e:
        logger.error("try_promotion error: %s", e)

# Admin commands
@bot.message_handler(commands=['admin'])
def cmd_admin(m: types.Message):
    if m.from_user.id != ADMIN_ID:
        bot.send_message(m.chat.id, "⛔ Siz admin emassiz.")
        return
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row("📊 Statistika", "📢 Broadcast")
    kb.row("🔙 Exit")
    bot.send_message(m.chat.id, "Admin panel:", reply_markup=kb)

@bot.message_handler(func=lambda m: m.text == "📊 Statistika" and m.from_user.id == ADMIN_ID)
def admin_stats(m: types.Message):
    cur.execute("SELECT COUNT(*) FROM users")
    total = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM users WHERE is_vip=1")
    vipc = cur.fetchone()[0]
    bot.send_message(m.chat.id, f"📈 Users: {total}\\n💎 VIP: {vipc}")

@bot.message_handler(func=lambda m: m.text == "📢 Broadcast" and m.from_user.id == ADMIN_ID)
def admin_broadcast(m: types.Message):
    msg = bot.send_message(m.chat.id, "Send broadcast text now (it will be sent to all users):")
    bot.register_next_step_handler(msg, do_broadcast)

def do_broadcast(m: types.Message):
    if m.from_user.id != ADMIN_ID: return
    cur.execute("SELECT id FROM users")
    users = [r[0] for r in cur.fetchall()]
    sent = 0
    for u in users:
        try:
            bot.send_message(u, f"📢 Admin: {m.text}")
            sent += 1
        except Exception:
            continue
    bot.send_message(m.chat.id, f"Sent to {sent}/{len(users)} users.")

# Callback for subscription check
@bot.callback_query_handler(func=lambda c: c.data == "check_join")
def cb_check(c: types.CallbackQuery):
    ok, err = check_subscriptions(c.from_user.id)
    if not ok:
        bot.send_message(c.message.chat.id, err)
        bot.answer_callback_query(c.id, "Hali o'sha kanallarga obuna bo'lmagansiz.")
        return
    add_or_update_user(c.from_user.id, c.from_user.username, c.from_user.first_name)
    bot.answer_callback_query(c.id, "✅ Obuna tekshirildi. Botdan foydalaning.")
    send_main_menu(c.message.chat.id)

# fallback
@bot.message_handler(func=lambda m: True)
def fallback(m: types.Message):
    if m.text.startswith("/refstat"):
        u = get_user(m.from_user.id)
        referrals = u[4] if u else 0
        bot.send_message(m.chat.id, f"Sizning referral count: {referrals}")
        return
    bot.send_message(m.chat.id, "Buyruqlar: /start, /admin, yoki menyudan tanlang.")

if __name__ == "__main__":
    logger.info("Bot started with polling...")
    while True:
        try:
            bot.infinity_polling(timeout=60, long_polling_timeout=60)
        except Exception as e:
            logger.exception("Polling error, restart in 5s: %s", e)
            time.sleep(5)