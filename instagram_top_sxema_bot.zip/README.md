# Instagram Top Sxema Bot  — Railway deploy (o'zbekcha)

Bot nomi: **Instagram Top Sxema Bot**
Bot username (misol): **@instagramheshteg2bot**

## Qisqacha
Bu loyiha Railway yoki Heroku ga joylashtirish uchun tayyor. Kod `bot.py` da, token va admin ID esa environment variables orqali kiritiladi.

## Fayllar
- `bot.py` — asosiy kod
- `requirements.txt` — Python paketlar
- `Procfile` — Railway/Heroku uchun
- `.env.example` — muhit o'zgaruvchilari namunasi
- `README.md` — bu fayl

## Deploy (Railway) — qadamlar (tez)
1. Railway (https://railway.app) saytida akkaunt bilan kirish.
2. New Project → Deploy from GitHub (yoki Upload).
3. GitHub repo tanlasangiz — repo ichiga ushbu loyihani joylang va Railway bilan bog'lang.
   Agar ZIP upload qilmoqchi bo'lsangiz — Railway Project → Upload files.
4. Railway project settings → Variables bo'limiga quyidagilarni qo'shing:
   - `TG_BOT_TOKEN` = (BotFather dan olingan token)
   - `ADMIN_ID` = 8077059920
   - `MANDATORY_CHANNELS` = @TopSxemaKana1,@instaheshteg2
   - `VIP_CHANNEL` = https://t.me/+6tyWFw8Ly1I5MTEy
   - `DB_PATH` = botdata.sqlite3
5. Deploy yoki Start service tugmasini bosing.
6. Agar hamma to'g'ri kiritilgan bo'lsa, bot ishga tushadi.

## Qanday ishlaydi
- Foydalanuvchi /start yuborsa, bot foydalanuvchi kanalga obuna ekanligini tekshiradi.
- Agar referral link orqali kirsa (`?start=ref<id>`) — referal hisobga olinadi.
- 50 ta referal → `is_vip` flag yoqiladi (adminga xabar ham keladi), 80+ — adminga e'lon (Rekka tahlili).
- VIP kanalga avtomatik qo'shish uchun botni VIP kanal admini qiling (aks holda admin sizlarni kanalga qo'shadi).

## Eslatma va xavfsizlik
- Tokenni hech qayerga ochiq joylashtirmang.
- Agar token avval chatga yuborilgan bo'lsa, BotFather orqali yangi token oling.
- Agar kanal tekshirishida xato chiqqan bo'lsa — botni kanalga admin qilib qo'ying.

Agar xohlasangiz — men ushbu ZIPni tayyorlab berdim, siz uni yuklab Railway ga joylaysiz. Qo'llab-quvvatlash: agar deployda xato chiqsa, log xatolarini menga yuboring, men tuzatib beraman.
